<?php
$cfg['ExecTimeLimit'] = 0;
